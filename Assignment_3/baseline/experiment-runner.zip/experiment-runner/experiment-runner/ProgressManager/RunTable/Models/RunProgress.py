from enum import Enum

class RunProgress(Enum):
    TODO = 1
    DONE = 2